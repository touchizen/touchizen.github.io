from flask import Blueprint, request, jsonify
from pptx import Presentation
from pptx.util import Inches, Pt
import matplotlib.pyplot as plt
import uuid
import os
import subprocess
import datetime

ttp_bp = Blueprint("ttp", __name__)
BASE_OUTPUT_DIR = "outputs"

def latex_to_image(latex_code, output_path):
    fig, ax = plt.subplots(figsize=(4, 2))
    ax.text(0.5, 0.5, f"${latex_code}$", fontsize=36, ha='center', va='center')
    ax.axis('off')
    plt.savefig(output_path, dpi=300, bbox_inches='tight', transparent=True)
    plt.close()

@ttp_bp.route("/v1/text-to-ppt", methods=["POST"])
def text_to_ppt():
    data = request.get_json()
    scenes = data.get("scenes", [])
    if not scenes:
        return jsonify({"error": "Missing 'scenes' array"}), 400

    today_str = datetime.date.today().strftime("%Y-%m-%d")
    output_dir = os.path.join(BASE_OUTPUT_DIR, "video", today_str)
    os.makedirs(output_dir, exist_ok=True)

    prs = Presentation()
    prs.slide_width = Inches(9)
    prs.slide_height = Inches(16)

    for scene in scenes:
        slide = prs.slides.add_slide(prs.slide_layouts[5])
        chalk = scene.get("chalkText", "")
        draw = scene.get("drawActions", "")

        if chalk.startswith("$$") and chalk.endswith("$$"):
            latex_code = chalk.strip("$$")
            img_filename = f"{uuid.uuid4().hex}.png"
            img_path = os.path.join(output_dir, img_filename)
            latex_to_image(latex_code, img_path)
            slide.shapes.add_picture(img_path, Inches(1), Inches(2), Inches(7), Inches(3))
            os.remove(img_path)
        else:
            textbox = slide.shapes.add_textbox(Inches(1), Inches(1), Inches(8), Inches(2))
            tf = textbox.text_frame
            tf.text = chalk

        textbox = slide.shapes.add_textbox(Inches(1), Inches(5), Inches(8), Inches(2))
        tf = textbox.text_frame
        p = tf.paragraphs[0]
        p.text = draw
        p.font.size = Pt(18)

    file_id = f"lecture_{uuid.uuid4().hex[:8]}"
    pptx_path = os.path.join(output_dir, f"{file_id}.pptx")
    prs.save(pptx_path)

    # 🔥 PPTX → PNG 변환
    slides_output_dir = os.path.join(output_dir, f"{file_id}_slides")
    os.makedirs(slides_output_dir, exist_ok=True)

    try:
        subprocess.run([
            "libreoffice",
            "--headless",
            "--convert-to", "png",
            "--outdir", slides_output_dir,
            pptx_path
        ], check=True)
    except subprocess.CalledProcessError as e:
        return jsonify({"error": f"PPT to PNG conversion failed: {str(e)}"}), 500

    base_url = request.host_url.rstrip("/")
    return jsonify({
        "pptx_url": f"{base_url}/static/video/{today_str}/{file_id}.pptx",
        "slides_folder": f"{base_url}/static/video/{today_str}/{file_id}_slides/",
        "file_id": file_id
    })
