from flask import Blueprint, request, jsonify
from tts_providers import elevenlabs
from mutagen.mp3 import MP3
import requests
import io

tts_bp = Blueprint("tts", __name__, url_prefix="/v1/tts")

@tts_bp.route("/<provider>/text-to-speech", methods=["POST"])
def text_to_speech(provider):
    data = request.json
    text = data.get("text")
    voice_id = data.get("voice_id")

    try:
        speed = float(data.get("speed", 1.0))
    except (TypeError, ValueError):
        speed = 1.0

    try:
        stability = float(data.get("stability", 0.3))
    except (TypeError, ValueError):
        stability = 0.3

    try:
        similarity_boost = float(data.get("similarity_boost", 0.8))
    except (TypeError, ValueError):
        similarity_boost = 0.8

    if not text:
        return jsonify({"error": "Missing 'text' field"}), 400

    if provider != "elevenlabs":
        return jsonify({"error": f"Provider '{provider}' is not supported"}), 400

    try:
        base_url = request.host_url.rstrip("/")
        result = elevenlabs.generate_tts_with_alignment(
            text,
            voice_id=voice_id,
            base_url=base_url,
            speed=speed,
            stability=stability,
            similarity_boost=similarity_boost
        )
        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@tts_bp.route("/mp3-duration", methods=["POST"])
def get_mp3_duration():
    data = request.json
    url = data.get("url")

    if not url:
        return jsonify({"error": "Missing 'url' field"}), 400

    try:
        response = requests.get(url)
        response.raise_for_status()

        audio = MP3(io.BytesIO(response.content))
        duration = round(audio.info.length, 2)  # seconds (소수점 2자리까지)

        return jsonify({"duration": duration})
    except Exception as e:
        return jsonify({"error": str(e)}), 500