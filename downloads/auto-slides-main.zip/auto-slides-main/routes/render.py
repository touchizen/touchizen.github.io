# routes/render.py
from flask import Blueprint, request, jsonify
from services.renderer import render_video_single, render_video_blocks

render_bp = Blueprint("render", __name__, url_prefix="/v1/render")

# --- 기존 싱글 내레이션 API ---
@render_bp.route("/video", methods=["POST"])
def render_video():
    data = request.get_json()
    try:
        base_url = request.host_url.rstrip("/")
        result = render_video_single(data, base_url=base_url)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# --- ✨ 새 다중 내레이션 API ---
@render_bp.route("/video-blocks", methods=["POST"])
def render_video_blocks_api():
    data = request.get_json()
    try:
        base_url = request.host_url.rstrip("/")
        result = render_video_blocks(data, base_url=base_url)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500