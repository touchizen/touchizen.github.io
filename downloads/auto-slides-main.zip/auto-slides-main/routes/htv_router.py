# routes/render.py  (새 파일)

from flask import Blueprint, request, jsonify, current_app
import subprocess, uuid, os, asyncio, shutil, tempfile, datetime
from playwright.async_api import async_playwright
import time
from utils.video import generate_video_index

htv_bp = Blueprint("htv", __name__, url_prefix="/v1")

# 캡처 + FFmpeg 함수를 asyncio 코루틴으로 분리
async def html_to_video(
        source: str,
        content_type: str = "html",        # "html" or "url"
        width=1080, height=1920,
        fps=30, seconds=4):

    total_frames = fps * seconds
    file_id      = f"vid_{uuid.uuid4().hex[:8]}"
    today_str    = datetime.date.today().strftime("%Y-%m-%d")
    output_dir   = os.path.join("outputs/video", today_str)
    os.makedirs(output_dir, exist_ok=True)

    out_dir      = tempfile.mkdtemp(prefix="frames_")
    video_path   = os.path.join(output_dir, f"{file_id}.mp4")

    RESET_JS = """
(() => {
	document.querySelectorAll('.typewriter').forEach(el => {
		const dur   = getComputedStyle(el).getPropertyValue('--dur')   || '2s';
		const steps = getComputedStyle(el).getPropertyValue('--steps') || '10';
		el.style.animation = 'none';
		// 강제 reflow
		void el.offsetWidth;
		el.style.animation = `typing ${dur} steps(${steps}) forwards`;
	});
})();
"""

    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=True,
            args=[
                "--no-sandbox",
                "--disable-background-timer-throttling",
                "--disable-backgrounding-occluded-windows",
                "--disable-renderer-backgrounding"
            ]
				)
        context = await browser.new_context(
            viewport={"width": width, "height": height},
            device_scale_factor=1,
            reduced_motion="no-preference"   # ← 애니메이션 ON
        )
        page = await context.new_page()

        if content_type == "url":
            await page.goto(source, wait_until="networkidle")
        else:                               # raw HTML 문자열
            await page.set_content(source, wait_until="networkidle")

        await page.evaluate(RESET_JS)
        await page.wait_for_timeout(100)   # ⬅︎ 애니메이션 시작 대기
        start_time = time.time()
        for i in range(total_frames):
            target_time = start_time + i / fps
            wait = max(0, target_time - time.time())
            if wait:
                await page.wait_for_timeout(wait * 1000)

            await page.screenshot(
                path=os.path.join(out_dir, f"f_{i:04}.jpg"),
                type="jpeg",
                quality=80,
                scale="css"
            )

        await browser.close()

        elapsed = time.time() - start_time
        real_fps = total_frames / elapsed
        current_app.logger.info(
            "capture: elapsed %.2fs (target %.2fs)  → real_fps %.2f",
            elapsed, seconds, real_fps,
        )

    # FFmpeg로 PNG 시퀀스 합치기
        subprocess.run([
            "ffmpeg", "-y",
            "-framerate", f"{real_fps:.02f}",          # ← 실측 fps
            "-i", os.path.join(out_dir, "f_%04d.jpg"),
            "-c:v", "libx264", "-pix_fmt", "yuv420p",
            video_path
        ], check=True)

    shutil.rmtree(out_dir)
    return file_id, video_path, today_str

# ────────────────────────────────────────────────
@htv_bp.route("/html-to-video", methods=["POST"])
def render_html_to_video():
    """
    요청 JSON 예:
    {
      "html": "<html>...</html>"          # 또는
      "url" : "https://example.com/slide",
      "width": 1080, "height": 1920,
      "fps": 30, "seconds": 4
    }
    """
    data    = request.get_json(silent=True) or {}
    html    = data.get("html")
    url     = data.get("url")
    width   = int(data.get("width",   1080))
    height  = int(data.get("height",  1920))
    fps     = int(data.get("fps",     30))
    seconds = int(data.get("seconds", 4))

    if not html and not url:
        return jsonify({"error": "either 'html' or 'url' must be provided"}), 400

    try:
        file_id, video_path, date_str = asyncio.run(html_to_video(
            source = html or url,
            content_type = "url" if url else "html",
            width = width, height = height,
            fps = fps, seconds = seconds
        ))
    except Exception as e:
        current_app.logger.error(f"Render error: {e}")
        return jsonify({"error": str(e)}), 500

    base_url    = request.host_url.rstrip("/")
    filename    = os.path.basename(video_path)
    public_path = f"/static/video/{date_str}/{filename}"
    abs_video_url = f"{base_url}{public_path}"

    # ⬇️ index.html 자동 생성
    generate_video_index(os.path.dirname(video_path), date_str, base_url)

    return jsonify({
        "video_url": abs_video_url,
        "file_id"  : file_id,
        "created"  : datetime.datetime.utcnow().isoformat() + "Z"
    }), 201
