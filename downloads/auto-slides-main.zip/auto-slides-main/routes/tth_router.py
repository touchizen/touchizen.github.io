# text_to_html.py
from flask import Blueprint, request, jsonify, current_app
from jinja2 import Environment, FileSystemLoader, select_autoescape
import uuid, os, datetime, re

tth_bp = Blueprint("tth", __name__)
BASE_OUTPUT_DIR = "outputs/html"
TEMPLATE_DIR = os.path.join(os.path.dirname(__file__), "templates")
os.makedirs(BASE_OUTPUT_DIR, exist_ok=True)

env = Environment(
    loader=FileSystemLoader(TEMPLATE_DIR),
    autoescape=select_autoescape(["html"])
)

@tth_bp.route("/v1/text-to-html", methods=["POST"])
def text_to_html():
    try:
        payload = request.get_json(silent=True) or {}
        scenes = payload.get("scenes", [])
        if not scenes:
            return jsonify({"error": "Missing 'scenes' array"}), 400

        compiled = []
        for sc in scenes:
            chalk = sc.get("chalkText", "")
            draw = sc.get("drawActions", "")
            img = sc.get("imageUrl")
            duration = sc.get("duration", 5)

            is_math = chalk.startswith(("$$", "$")) and chalk.endswith(("$$", "$"))
            chalk_raw = chalk.replace("\\", "\\\\")  # \\ 이스케이프

            plain_len = len(re.sub(r"\$+", "", chalk_raw))
            steps = max(plain_len // 2, 10)

            compiled.append({
                "chalk_is_math": is_math,
                "chalk_raw": chalk_raw,
                "draw": draw,
                "imageUrl": img,
                "steps": steps,
                "dur": round(steps / 12, 2),
                "font": sc.get("font", 72),
                "duration": duration
            })

        file_id = f"html_{uuid.uuid4().hex[:8]}"
        html_fname = f"{file_id}.html"

        # 날짜별 디렉토리
        today_str = datetime.date.today().strftime("%Y-%m-%d")
        dated_dir = os.path.join(BASE_OUTPUT_DIR, today_str)
        os.makedirs(dated_dir, exist_ok=True)
        html_path = os.path.join(dated_dir, html_fname)

        mode = payload.get("mode", "slide")
        template_name = "scroll.html" if mode == "scroll" else "slides.html"
        title_str = f"{'Scroll' if mode == 'scroll' else 'Slides'} {today_str}"

        template = env.get_template(template_name)
        html = template.render(
            title=title_str,
            width=1080,
            height=1920,
            scenes=compiled
        )

        with open(html_path, "w", encoding="utf-8") as fp:
            fp.write(html)

        generate_daily_index(dated_dir, today_str)

        # 절대 URL 생성
        base_url = request.host_url.rstrip("/")
        public_path = f"/static/html/{today_str}/{html_fname}"
        abs_html_url = f"{base_url}{public_path}"

        return jsonify({
            "html_url": abs_html_url,
            "file_id": file_id,
            "slide_count": len(scenes)
        }), 201

    except Exception as e:
        current_app.logger.error(f"❌ HTML generation error: {e}")
        return jsonify({"error": f"Internal server error: {str(e)}"}), 500


def generate_daily_index(directory: str, date_str: str):
    """지정한 날짜 디렉토리에 index.html 생성"""
    html_files = [
        fname for fname in os.listdir(directory)
        if fname.endswith(".html") and fname != "index.html"
    ]
    html_files.sort()

    index_path = os.path.join(directory, "index.html")
    with open(index_path, "w", encoding="utf-8") as f:
        f.write(f"<html><head><title>{date_str} HTML List</title></head><body>\n")
        f.write(f"<h2>HTML files created on {date_str}</h2><ul>\n")
        for fname in html_files:
            f.write(f'<li><a href="{fname}" target="_blank">{fname}</a></li>\n')
        f.write("</ul></body></html>")
