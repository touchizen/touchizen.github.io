# auto-slides
자동으로 강의 동영상을 제작해 주는  api 서버
