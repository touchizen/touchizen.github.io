# services/renderer.py
import os
import requests
import logging
import hashlib
import re
import time 
from datetime import datetime
import numpy as np

from moviepy import (
    VideoFileClip,
    AudioFileClip,
    ColorClip,
    AudioClip,
    CompositeVideoClip,
    CompositeAudioClip,
    concatenate_videoclips,
    concatenate_audioclips
)

try:
    # MoviePy 2.x (권장 new path)
    from moviepy.video.fx.Loop import Loop as vfx_loop
    from moviepy.audio.fx.AudioLoop import AudioLoop as afx_loop
except ImportError:          # 1.x fallback
    from moviepy.video.fx.All import loop as vfx_loop
    from moviepy.audio.fx.Audio_loop import audio_loop as afx_loop

from utils.srt import generate_subtitle_clips_from_alignment
from utils.video import generate_video_index, generate_title_clip

OUTPUT_DIR = "outputs"
CACHE_DIR = os.path.join(OUTPUT_DIR, "cache")
os.makedirs(CACHE_DIR, exist_ok=True)

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

DELAY_LAST = 2.0      # 마지막 내레이션 앞에서 비울 시간
BEEP_FREQ  = 1000     # Hz
BEEP_LEN   = 0.10     # 초
SAMPLE_RATE = 44100   # Hz

# ---------- 유틸 ----------
def url_to_filename(url: str) -> str:
    """URL을 MD5 해시로 변환해 고유 파일명 반환 (확장자 유지)"""
    url_hash = hashlib.md5(url.encode("utf-8")).hexdigest()
    ext = os.path.splitext(url)[1]
    return f"{url_hash}{ext}"

def download_file(url: str) -> str:
    filename = url_to_filename(url)
    save_path = os.path.join(CACHE_DIR, filename)

    if os.path.exists(save_path):
        logger.info(f"✅ Cached: {filename}")
        return save_path

    resp = requests.get(url, timeout=30)
    resp.raise_for_status()
    with open(save_path, "wb") as f:
        f.write(resp.content)

    logger.info(f"Downloaded: {filename}")
    return save_path

def natural_key(s: str):
    m = re.search(r"\d+", s)
    return int(m.group()) if m else 0

# ── 비프 클립 생성 함수 -----------------------------------------
def make_beep(start_t: float) -> AudioClip:
    def tone(t):
        return (np.sin(2*np.pi*BEEP_FREQ*(t-start_t)) *
                ((t >= start_t) & (t < start_t + BEEP_LEN)))
    return AudioClip(tone, duration=start_t + BEEP_LEN, fps=SAMPLE_RATE)

# ---------- 메인 ----------
def render_video_single(data: dict, base_url: str = "") -> dict:
    try:
        start_ts = time.time()

        width, height, fps = 1080, 1920, 30

        # 1) 파일 다운로드 -----------------------------------------------------
        downloads = {
            k: download_file(u) for k, u in data.items() if u and u.startswith("http")
        }
        if "narration" not in downloads:
            raise ValueError("narration key is missing in data")

        # 2) 날짜 기반 경로 설정 -----------------------------------------------
        today_str = datetime.now().strftime("%Y-%m-%d")
        dated_dir = os.path.join(OUTPUT_DIR, "video", today_str)
        os.makedirs(dated_dir, exist_ok=True)

        file_id = os.path.splitext(os.path.basename(downloads["narration"]))[0]
        output_path = os.path.join(dated_dir, f"{file_id}.mp4")

        # 3) 비디오·오디오 -----------------------------------------------------
        narration_audio = AudioFileClip(downloads["narration"])

        scene_keys = sorted([k for k in downloads if k.startswith("scene")], key=natural_key)
        sound_keys = sorted([k for k in downloads if k.startswith("sound")], key=natural_key)

        video_layers = []
        audio_layers = [narration_audio]

        start_time = 0.0
        for sk in scene_keys:
            clip = VideoFileClip(downloads[sk])
            if clip.w != width or clip.h != height:
                clip = clip.resize(width=width, height=height)

            clip.start = start_time
            video_layers.append(clip)
            start_time += clip.duration

        audio_start = 0.0
        for ak in sound_keys:
            a = AudioFileClip(downloads[ak])
            a.start = audio_start
            audio_layers.append(a)
            audio_start += a.duration

        base_audio = CompositeAudioClip(audio_layers)

        # 4) 자막 -------------------------------------------------------------
        subtitle_clips = []
        align_path = downloads.get("alignment_url")
        if align_path and os.path.exists(align_path):
            subtitle_clips = generate_subtitle_clips_from_alignment(
                align_path, width, height
            )

        # 5) 영상 합치기 -------------------------------------------------------
        base_video = CompositeVideoClip(video_layers + subtitle_clips, size=(width, height))
        base_video.audio = base_audio

        # 6) 렌더링 -----------------------------------------------------------
        logger.info(f"Rendering to {output_path}")
        base_video.write_videofile(
            output_path,
            fps=fps,
            codec="libx264",
            preset="veryfast",
            audio_codec="libmp3lame",
            temp_audiofile=f"{output_path}.temp.mp3",
            threads=4,
            remove_temp=True,
        )

        # 7) 🔹 인덱스 생성
        generate_video_index(dated_dir, today_str, base_url)

        return {
            "video_url": f"{base_url}/static/video/{today_str}/{file_id}.mp4",
            "file_id": file_id,
            "elapsed_time": round(time.time() - start_ts, 2)
        }

    except Exception as e:
        logger.exception(f"Error while rendering video: {e}")
        raise

# ──────────────── 메인 렌더러 ─────────────────────────────────────────────────
def render_video_blocks(data: dict, base_url: str = "") -> dict:
    """
    data 예시
    {
      "narration1":  "https://…/n1.mp3",
      "scene1":      "https://…/s1.mp4",
      "sound1":      "https://…/fx1.mp3",
      "alignment1":  "https://…/a1.json",

      "narration2":  "https://…/n2.mp3",
      "scene2":      "https://…/s2.mp4",
      "alignment2":  "https://…/a2.json"
    }
    → narrationN 길이만큼 sceneN·soundN 을 trim/loop, alignmentN 자막을 맞춰 블록별로 합성.
    """

    narr_keys = sorted(
        [k for k in data.keys() if re.match(r"^narration\d*$", k) and data[k]],
        key=natural_key
    )

    if not narr_keys:
        # narration이 하나도 없으면 전용 함수로 위임
        logger.info("[render_video_blocks] no narration → fallback to _no_narration()")
        return render_video_blocks_no_narration(data, base_url)
    
    try:
        t0 = time.time()
        WIDTH, HEIGHT, FPS = 1080, 1920, 30

        # 1) 다운로드 ---------------------------------------------------------
        downloads = {
            k: download_file(u) for k, u in data.items() if isinstance(u, str) and u.startswith("http")
        }

        # narr_keys = sorted([k for k in downloads if re.match(r"^narration\d*$", k)],  key=natural_key)
        # if not narr_keys:
        #     raise ValueError("narration1 키가 최소 1개 필요합니다.")

        scene_keys     = sorted([k for k in downloads if k.startswith("scene")],     key=natural_key)
        sound_keys     = sorted([k for k in downloads if k.startswith("sound")],     key=natural_key)
        align_keys     = sorted([k for k in downloads if k.startswith("alignment")], key=natural_key)
        subtitle_keys  = sorted([k for k in data      if k.startswith("subtitle")],  key=natural_key)

        title = data.get("title", "")

        # 2) 출력 폴더 --------------------------------------------------------
        today   = datetime.now().strftime("%Y-%m-%d")
        out_dir = os.path.join(OUTPUT_DIR, "video", today)
        os.makedirs(out_dir, exist_ok=True)

        file_id     = os.path.splitext(os.path.basename(downloads[narr_keys[0]]))[0]
        output_path = os.path.join(out_dir, f"{file_id}.mp4")

        # 3) 클립 합성 --------------------------------------------------------
        video_layers, audio_layers, sound_layers, subtitle_layers = [], [], [], []
        timeline = 0.0  # 누적 시작 시간
        debug_rows = []
        frame_rate = FPS             # 디버그용 fps

        for idx, nkey in enumerate(narr_keys):

            # ── 내레이션 ────────────────────────────────────────────────────
            narr_clip = AudioFileClip(downloads[nkey])
            logger.info(f"{nkey} = {downloads[nkey]}")

            narr_clip.start = timeline
            narr_dur  = narr_clip.duration
            audio_layers.append(narr_clip)

            # ── scene<i> ───────────────────────────────────────────────────
            scene_dur = None
            if idx < len(scene_keys):
                v = VideoFileClip(downloads[scene_keys[idx]])
                logger.info(f"Video{idx} = {downloads[scene_keys[idx]]}")

                if (v.w, v.h) != (WIDTH, HEIGHT):
                    v = v.resized(new_size=(WIDTH, HEIGHT))

                v = v if v.duration >= narr_dur else v.with_effects([vfx_loop(duration=narr_dur)])
                v = v.subclipped(0, narr_dur)
                v.start = timeline
                scene_dur = v.duration
                video_layers.append(v)

            # # ── sound<i> (효과음) ───────────────────────────────────────────
            sound_dur = None
            if idx < len(sound_keys):
                s = AudioFileClip(downloads[sound_keys[idx]])
                logger.info(f"Audio{idx} = {downloads[sound_keys[idx]]}")
                s = s if s.duration >= narr_dur else s.with_effects([afx_loop(duration=narr_dur)])
                s = s.subclipped(0, narr_dur)
                s.start = timeline
                sound_dur = s.duration
                sound_layers.append(s)

            # # ── alignment<i> (자막) ────────────────────────────────────────
            if idx < len(align_keys):
                sub_path = downloads[align_keys[idx]]
                logger.info(f"Align{idx} = {downloads[align_keys[idx]]}")
                subs = generate_subtitle_clips_from_alignment(sub_path, WIDTH, HEIGHT)
                for clip in subs:
                    clip = clip.with_start(clip.start + timeline)
                    subtitle_layers.append(clip)

            # ⑤ 디버그 정보 누적 ---------------------------------------
            debug_rows.append({
                "block": idx + 1,
                "start": round(timeline, 2),
                "end":   round(timeline + narr_dur, 2),
                "narr":  round(narr_dur, 2),
                "scene": round(scene_dur, 2)  if scene_dur  else None,
                "sound": round(sound_dur, 2)  if sound_dur  else None,
                "frames": int(narr_dur * frame_rate)               # 예상 프레임 수
            })

            timeline += narr_dur

        title_clip = generate_title_clip(
            title=title,
            width=WIDTH,
            height=HEIGHT,
            duration=5,        # 영상 전체 길이
            font_size=60,
            y_offset_px=100            # 상단에서 80px 위치
        )

        audioOnly = concatenate_audioclips(audio_layers)
        videoOnly = concatenate_videoclips(video_layers)
        soundOnly = concatenate_audioclips(sound_layers)

        # 합성 전에 **모든 블록 목록**을 한 번에 출력
        logger.info("──────────────── BLOCK SUMMARY ────────────────")
        for row in debug_rows:
            logger.info(
                f"[{row['block']:>2}] {row['start']:>6}s → {row['end']:>6}s | "
                f"narr={row['narr']:>5}s scene={row['scene'] or 'N/A':>5} "
                f"sound={row['sound'] or 'N/A':>5} frames≈{row['frames']}"
            )
        logger.info(f"videoLen = {len(video_layers)}")
        logger.info(f"audioLen = {len(audio_layers)}")        
        logger.info("───────────────────────────────────────────────")

        # 4) 최종 합성 ----------------------------------------------------
        overlay_clips = [videoOnly] + subtitle_layers
        if title_clip:                                   # 타이틀이 있으면 최상단에 얹기
            overlay_clips.append(title_clip)

        # 4) 최종 합성 --------------------------------------------------------
        base_video              = CompositeVideoClip(overlay_clips, size=(WIDTH, HEIGHT))
        base_video.audio        = CompositeAudioClip([audioOnly,soundOnly])
        #base_video.duration     = timeline  # 안전하게 길이 고정
        #base_video.fps          = FPS

        logger.info(f"🎞  rendering → {output_path}")
        base_video.write_videofile(
            output_path,
            fps=FPS,
            codec="libx264",
            preset="veryfast",
            audio_codec="libmp3lame",
            temp_audiofile=f"{output_path}.temp.mp3",
            threads=4,
            remove_temp=True,
        )

        # 5) 인덱스 갱신 ------------------------------------------------------
        generate_video_index(out_dir, today, base_url)

        return {
            "video_url": f"{base_url}/static/video/{today}/{file_id}.mp4",
            "file_id": file_id,
            "elapsed_time": round(time.time() - t0, 2),
        }

    except Exception as e:
        logger.exception("[render_video_blocks] error")
        raise

def render_video_blocks_no_narration(data: dict, base_url: str = "") -> dict:
    """
    narration 없이 sceneN, soundN, alignmentN 만으로 구성된 블록을 렌더링
    각 scene/sound는 duration이 부족하면 loop되고, alignment 자막도 지원함
    """

    try:
        t0 = time.time()
        WIDTH, HEIGHT, FPS = 1080, 1920, 30

        downloads = {
            k: download_file(u) for k, u in data.items() if isinstance(u, str) and u.startswith("http")
        }

        scene_keys = sorted([k for k in downloads if k.startswith("scene")], key=natural_key)
        sound_keys = sorted([k for k in downloads if k.startswith("sound")], key=natural_key)
        align_keys = sorted([k for k in downloads if k.startswith("alignment")], key=natural_key)
        subtitle_keys  = sorted([k for k in data  if k.startswith("subtitle")],  key=natural_key)[1:]

        max_blocks = max(len(scene_keys), len(sound_keys), len(align_keys), len(subtitle_keys)+1)
        if max_blocks == 0:
            raise ValueError("최소 하나 이상의 scene/sound/alignment 항목이 필요합니다.")

        title = data.get("title", "")
        today = datetime.now().strftime("%Y-%m-%d")
        out_dir = os.path.join("outputs", "video", today)
        os.makedirs(out_dir, exist_ok=True)

        file_id = f"nonarr_{int(time.time())}"
        output_path = os.path.join(out_dir, f"{file_id}.mp4")

        video_layers, audio_layers, subtitle_layers = [], [], []
        timeline = 0.0

        for idx in range(max_blocks):
            skey = f"scene{idx+1}"
            fxkey = f"sound{idx+1}"
            akey = f"alignment{idx+1}"

            block_dur = 5.0  # 기본값: 각 블록당 5초

            if skey in downloads:
                v = VideoFileClip(downloads[skey])
                if (v.w, v.h) != (WIDTH, HEIGHT):
                    v = v.resized(new_size=(WIDTH, HEIGHT))
                v = v if v.duration >= block_dur else vfx_loop(v, duration=block_dur)
                v = v.subclipped(0, block_dur)
                v.start = timeline
                video_layers.append(v)

            if fxkey in downloads:
                s = AudioFileClip(downloads[fxkey])
                s = s if s.duration >= block_dur else afx_loop(s, duration=block_dur)
                s = s.subclipped(0, block_dur)
                s.start = timeline
                audio_layers.append(s)

            if akey in downloads:
                subs = generate_subtitle_clips_from_alignment(downloads[akey], WIDTH, HEIGHT)
                for clip in subs:
                    clip.start = clip.start + timeline
                    subtitle_layers.append(clip)

            if idx > 0:                               # 첫 블록(0)은 스킵
                sub_idx = idx - 1                     # 인덱스 한 칸 당김
                if sub_idx < len(subtitle_keys):
                    txt = data.get(subtitle_keys[sub_idx])
                    if txt:
                        tclip = generate_title_clip(
                            title       = txt,
                            width       = WIDTH,
                            height      = HEIGHT,
                            duration    = block_dur,
                            font_size   = 48,
                            y_offset_px = 100,
                            start_time  = timeline
                        )
                        subtitle_layers.append(tclip)

            timeline += block_dur

        title_clip = generate_title_clip(
            title=title,
            width=WIDTH,
            height=HEIGHT,
            duration=5,        # 영상 전체 길이
            font_size=50,
            y_offset_px=100            # 상단에서 80px 위치
        ) if title else None

        # if title_clip:                                   # 타이틀이 있으면 최상단에 얹기
        #     title_layers.insert(0,title_clip)

        videoOnly = concatenate_videoclips(video_layers)
        soundOnly = concatenate_audioclips(audio_layers)

        overlay_clips = [videoOnly] + subtitle_layers
        if title_clip:
            overlay_clips.insert(1, title_clip)  # 최상단 고정        
            
        base_video = CompositeVideoClip(overlay_clips, size=(WIDTH, HEIGHT))
        base_audio = soundOnly
        if base_audio:
            base_video.audio = base_audio

        base_video.write_videofile(
            output_path,
            fps=FPS,
            codec="libx264",
            preset="veryfast",
            audio_codec="libmp3lame",
            temp_audiofile=f"{output_path}.temp.mp3",
            threads=4,
            remove_temp=True,
        )

        generate_video_index(out_dir, today, base_url)

        return {
            "video_url": f"{base_url}/static/video/{today}/{file_id}.mp4",
            "file_id": file_id,
            "elapsed_time": round(time.time() - t0, 2),
        }

    except Exception as e:
        logger.exception("[render_video_blocks_no_narration] error")
        raise
