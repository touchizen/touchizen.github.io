python3 merge_openapi.py
