#!/bin/bash
# 1. 빌드 & 실행
docker compose up -d --build

# 2. 브라우저에서 Swagger 확인
http://localhost:8080/docs

# 3. curl 테스트
curl -X POST http://localhost:8080/v1/elevenlabs/text-to-speech \
     -H "Content-Type: application/json" \
     -d '{"text": "타이밍 정보를 포함한 음성을 생성합니다."}'
