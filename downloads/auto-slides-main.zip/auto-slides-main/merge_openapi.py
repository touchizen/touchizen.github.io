import yaml
import os

BASE_YAML = "openapi/main.yaml"
PATHS_DIR = "openapi/paths"
OUTPUT_FILE = "docs/openapi.yaml"

# Load base file
with open(BASE_YAML, "r", encoding="utf-8") as f:
    openapi = yaml.safe_load(f)

# Ensure 'paths' exists
openapi["paths"] = {}

# Merge each path file
for filename in sorted(os.listdir(PATHS_DIR)):
    if filename.endswith(".yaml"):
        with open(os.path.join(PATHS_DIR, filename), "r", encoding="utf-8") as f:
            path_yaml = yaml.safe_load(f)
            openapi["paths"].update(path_yaml)

# Save merged result
os.makedirs("docs", exist_ok=True)
with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
    yaml.dump(openapi, f, sort_keys=False, allow_unicode=True)

print(f"✅ Merged OpenAPI written to {OUTPUT_FILE}")
