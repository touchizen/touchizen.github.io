#!/bin/bash
xcrun simctl io booted recordVideo ./outputs/record/simulator.mp4