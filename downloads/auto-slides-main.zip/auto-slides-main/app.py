from flask import Flask, request, send_from_directory, jsonify
import logging
import time
import os

# 기본 로그 세팅
logging.basicConfig(level=logging.INFO)

app = Flask(__name__)

# ── 1. 요청 들어올 때 로그 ─────────────────────────────
@app.before_request
def log_request_info():
    request.start_time = time.time()   # 요청 시간 기록
    logging.info(f"➡️ Request: {request.method} {request.path}")
    if request.is_json:
        logging.info(f"   Request JSON: {request.get_json()}")
    else:
        logging.info(f"   Request Data: {request.data}")


# ── 2. 응답 나갈 때 로그 ─────────────────────────────
@app.after_request
def log_response_info(response):
    duration = time.time() - request.start_time
    logging.info(f"⬅️ Response: {response.status_code} {request.path} ({duration:.2f}s)")

    try:
        if not response.direct_passthrough:
            response_data = response.get_json()
            logging.info(f"   Response JSON: {response_data}")
        else:
            logging.info(f"   Response Data: <streamed file passthrough>")
    except Exception:
        logging.info(f"   Response Data: <unreadable or non-JSON>")
    return response


# ── 기존 코드 계속 ───────────────────────────────────
from routes.tts_router import tts_bp
from routes.ttp_router import ttp_bp
from routes.tth_router import tth_bp
from routes.htv_router import htv_bp
from routes.render import render_bp
from flask_swagger_ui import get_swaggerui_blueprint

app.static_folder = 'docs'
app.register_blueprint(tts_bp)
app.register_blueprint(ttp_bp)
app.register_blueprint(tth_bp)
app.register_blueprint(htv_bp)
app.register_blueprint(render_bp)

@app.route("/static/audio/<date>/")
@app.route("/static/audio/<date>/<filename>")
def serve_audio_by_date(date, filename="index.html"):
    return send_from_directory(os.path.join("outputs/audio", date), filename)

@app.route("/static/video/<date>/")
@app.route("/static/video/<date>/<filename>")
def serve_video_by_date(date, filename="index.html"):
    return send_from_directory(os.path.join("outputs/video", date), filename)

@app.route("/static/html/<date>/")
@app.route("/static/html/<date>/<filename>")
def serve_html_by_date(date, filename="index.html"):
    return send_from_directory(os.path.join("outputs/html", date), filename)

@app.route("/static/image/<path:filename>")
def serve_static(filename):
    return send_from_directory("static", filename)

SWAGGER_URL = "/docs"
API_URL = "/static/openapi.yaml"
swaggerui_blueprint = get_swaggerui_blueprint(
    SWAGGER_URL,
    API_URL,
    config={"app_name": "ElevenLabs TTS + Video Render API"}
)
app.register_blueprint(swaggerui_blueprint, url_prefix=SWAGGER_URL)

if __name__ == "__main__":
    os.makedirs("outputs", exist_ok=True)
    app.run(host="0.0.0.0", port=8080)
