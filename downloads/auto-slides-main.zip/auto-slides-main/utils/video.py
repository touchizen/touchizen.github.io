import os
from moviepy import TextClip
from typing import Optional

def generate_video_index(directory: str, date_str: str, base_url: str):
    """
    지정한 날짜 디렉토리에 index.html 생성 (video 목록)
    """
    video_files = [
        fname for fname in os.listdir(directory)
        if fname.endswith(".mp4")
    ]
    video_files.sort()

    index_path = os.path.join(directory, "index.html")
    with open(index_path, "w", encoding="utf-8") as f:
        f.write(f"<html><head><title>{date_str} Videos</title></head><body>\n")
        f.write(f"<h2>📽️ Videos generated on {date_str}</h2><ul>\n")
        for fname in video_files:
            video_url = f"{base_url}/static/video/{date_str}/{fname}"
            f.write(f'<li><p>{fname}</p>\n')
            f.write(f'<video width="360" controls preload="metadata">\n')
            f.write(f'  <source src="{video_url}" type="video/mp4">\n')
            f.write(f'  Your browser does not support the video tag.\n')
            f.write('</video></li>\n')
        f.write("</ul></body></html>")


def generate_title_clip(
    title: str,
    width: int,
    height: int,
    *,
    duration: float,
    font_size: int = 60,
    font: str = "NanumGothicBold",
    color: str = "white",
    stroke_color: str = "black",
    stroke_width: int = 3,
    y_offset_px: int = 100,          # 화면 위쪽에서 얼마나 내려올지(px)
    opacity: float = 0.9,
    start_time: float = 0
) -> Optional[TextClip]:
    """
    ■ title       : 화면에 표시할 문자열 (빈 문자열이면 None 반환)
    ■ width/height: 비디오 해상도
    ■ duration    : 타이틀을 유지할 시간(전체 길이 등)
    반환           : moviepy TextClip (없으면 None)
    """
    if not title:
        return None

    clip = (
        TextClip(
            text=title,
            font=font,
            font_size=font_size,
            color=color,
            stroke_color=stroke_color,
            stroke_width=stroke_width,
            method="caption",
            size=(int(width * 0.9), 400),   # 가로 90 % 안에서 자동 줄바꿈
        )
        .with_start(start_time)                        # 0 초부터
        .with_duration(duration)              # 전체 지속
        .with_position(("center", y_offset_px))
        .with_opacity(opacity)
    )
    return clip