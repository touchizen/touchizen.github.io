import os
import json
import re
from datetime import timedelta
from moviepy import TextClip
from typing import List, Dict, Optional

# --- 태그 판단용 정규식 ---
TAG_START_RE = re.compile(r"<\s*break", re.I)          # 태그 시작
TAG_FULL_RE  = re.compile(r"<\s*break\b[^>]*?>", re.I) # 한 줄 안에 다 들어왔을 때 제거용

def clean_words(words: List[Dict]) -> List[Dict]:
    """
    alignment["words"] 배열에서 <break …/> 태그를 통째로 제거해
    (토큰이 분리돼 있든 한 덩어리로 있든 모두 처리)
    """
    cleaned: List[Dict] = []
    buffering = False  # 태그 내부를 읽는 중인가?
    
    for w in words:
        t = w["text"]

        # 1) 태그 시작
        if TAG_START_RE.match(t):
            if ">" not in t:      # <break 로 시작했지만 아직 '>' 없음 → 버퍼링 시작
                buffering = True
            # ‘<break …/>’가 한 토큰에 다 들어온 경우 그냥 무시
            continue
        
        # 2) 태그 내부 계속 읽기
        if buffering:
            if ">" in t:          # 태그 끝났으면 버퍼링 종료
                buffering = False
            continue              # 태그 내용은 스킵
        
        # 3) 일반 단어 → 혹시 모를 잔여 태그 한 번 더 제거
        text_no_tag = TAG_FULL_RE.sub("", t).strip()
        if text_no_tag:
            cleaned.append({**w, "text": text_no_tag})
    
    return cleaned

def seconds_to_srt_time(seconds: float) -> str:
    """float 초를 SRT 포맷으로 변환 (hh:mm:ss,mmm)"""
    td = timedelta(seconds=seconds)
    total_seconds = int(td.total_seconds())
    millis = int((td.total_seconds() - total_seconds) * 1000)
    return f"{str(td)}".split('.')[0].zfill(8).replace(":", ":") + f",{millis:03d}"

def generate_srt_from_alignment(alignment_data: dict, output_path: str = "output.srt", group_words: int = 4):
    """
    alignment 데이터를 기반으로 .srt 자막 파일 생성
    - group_words: 몇 개 단어마다 한 줄로 묶을지 (기본: 4)
    """
    alignment = alignment_data.get("alignment", [])
    if not alignment:
        raise ValueError("alignment 정보가 비어 있습니다.")

    with open(output_path, "w", encoding="utf-8") as f:
        idx = 1
        for i in range(0, len(alignment), group_words):
            group = alignment[i:i + group_words]
            start = group[0]["start"]
            end = group[-1]["end"]
            words = " ".join([w["word"] for w in group])

            f.write(f"{idx}\n")
            f.write(f"{seconds_to_srt_time(start)} --> {seconds_to_srt_time(end)}\n")
            f.write(f"{words}\n\n")
            idx += 1

    print(f"✅ SRT 파일 생성 완료: {output_path}")


# ────────────────────────────────────────────────────────────────
# 2) generate_subtitle_clips_from_alignment()
#    - clean_words() 로 태그 제거 후 자막 TextClip 생성
# ────────────────────────────────────────────────────────────────
def generate_subtitle_clips_from_alignment(
    alignment_json,
    width: int,
    height: int,
    *,
    font_size: int = 60,
    font: str = "NanumGothic",
    color: str = "yellow",
    stroke_color: str = "black",
    stroke_width: int = 2,
    y_offset_ratio: float = 0.70,
    group_duration: float = 1.0
) -> List[TextClip]:
    """
    alignment_json : 파일 경로(str) 또는 dict
    width,height   : 비디오 해상도
    반환           : 일정 시간마다 문장 단위로 끊긴 TextClip 리스트
    """
    # ① JSON 로드
    if isinstance(alignment_json, (str, os.PathLike)):
        data = json.load(open(alignment_json, "r", encoding="utf8"))
    else:
        data = alignment_json

    # ② <break …/> 제거
    merged = clean_words(data["words"])

    # ③ TextClip 생성
    clips: List[TextClip] = []
    buf_words, current_start, group_end = [], None, None

    for w in merged:
        text = w["text"]
        start, end = float(w["start"]), float(w["end"])

        if current_start is None:
            current_start = start

        buf_words.append(text)
        group_end = end

        # group_duration 초마다 끊어서 하나의 자막으로
        if group_end - current_start >= group_duration:
            clip = (
                TextClip(
                    text=" ".join(buf_words),
                    font=font,
                    font_size=font_size,
                    color=color,
                    stroke_color=stroke_color,
                    stroke_width=stroke_width,
                    method="caption",
                    size=(int(width * 0.9), 100),
                )
                .with_start(current_start)
                .with_duration(group_end - current_start)
                .with_position(("center", int(height * y_offset_ratio)))
            )
            clips.append(clip)
            buf_words, current_start = [], None

    # 남은 단어 처리
    if buf_words and current_start is not None and group_end is not None:
        clip = (
            TextClip(
                text=" ".join(buf_words),
                font=font,
                font_size=font_size,
                color=color,
                stroke_color=stroke_color,
                stroke_width=stroke_width,
                method="caption",
                size=(int(width * 0.9), 100),
            )
            .with_start(current_start)
            .with_duration(group_end - current_start)
            .with_position(("center", int(height * y_offset_ratio)))
        )
        clips.append(clip)

    return clips