import os
import uuid
import json
import logging
from io import BytesIO
from datetime import datetime
from dotenv import load_dotenv
from elevenlabs.client import ElevenLabs
from mutagen.mp3 import MP3

# 로그 레벨 설정
logging.basicConfig(level=logging.INFO)

# 환경변수 로드
load_dotenv()

BASE_OUTPUT_DIR = "outputs/audio"
os.makedirs(BASE_OUTPUT_DIR, exist_ok=True)

def generate_tts_with_alignment(
        text: str,
        voice_id: str = None,
        base_url: str = "",
        *,
        speed: float = 1.0,
        stability: float = 0.3,
        similarity_boost: float = 0.8
    ) -> dict:

    api_key = os.getenv("ELEVENLABS_API_KEY")
    default_voice_id = os.getenv("ELEVENLABS_VOICE_ID")

    if not api_key:
        raise ValueError("Missing ELEVENLABS_API_KEY in .env")

    voice_id = voice_id or default_voice_id
    if not voice_id:
        raise ValueError("Missing voice_id (parameter or .env)")

    client = ElevenLabs(api_key=api_key)

    cleaned_text = text.replace('\u000b', '')
    audio_generator = client.text_to_speech.convert(
        text=cleaned_text,
        voice_id=voice_id,
        model_id="eleven_multilingual_v2",
        output_format="mp3_44100_192",
        voice_settings={
            "stability": stability,
            "similarity_boost": similarity_boost,
            "speed": speed
        }
    )

    audio_bytes = b"".join(audio_generator)

    # 🔹 날짜별 디렉토리
    today_str = datetime.now().strftime("%Y-%m-%d")
    output_dir = os.path.join(BASE_OUTPUT_DIR, today_str)
    os.makedirs(output_dir, exist_ok=True)

    file_id = uuid.uuid4().hex
    mp3_path = os.path.join(output_dir, f"{file_id}.mp3")
    json_path = os.path.join(output_dir, f"{file_id}.json")

    # MP3 저장
    with open(mp3_path, "wb") as f:
        f.write(audio_bytes)

    audio = MP3(mp3_path)
    duration_seconds = audio.info.length

    # Alignment 저장
    audio_io = BytesIO(audio_bytes)
    alignment = client.forced_alignment.create(file=audio_io, text=text)

    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(alignment.dict(), f, indent=2, ensure_ascii=False)

    generate_audio_index(output_dir, today_str, base_url)
    # 🔹 URL도 날짜 경로 포함하여 반환
    return {
        "audio_url": f"{base_url}/static/audio/{today_str}/{file_id}.mp3",
        "alignment_url": f"{base_url}/static/audio/{today_str}/{file_id}.json",
        "file_id": file_id,
        "speed": round(speed, 2),
        "stability": round(stability, 2),
        "similarity_boost": round(similarity_boost, 2),
        "duration": round(duration_seconds, 2)
    }


def generate_audio_index(directory: str, date_str: str, base_url: str):
    """
    지정한 날짜 디렉토리에 index.html 생성 (audio 목록용)
    """
    files = sorted(os.listdir(directory))
    mp3_files = [f for f in files if f.endswith(".mp3")]
    json_files = [f for f in files if f.endswith(".json")]

    index_path = os.path.join(directory, "index.html")
    with open(index_path, "w", encoding="utf-8") as f:
        f.write(f"<html><head><title>{date_str} Audio List</title></head><body>\n")
        f.write(f"<h2>🔊 Audio files generated on {date_str}</h2><ul>\n")

        for mp3 in mp3_files:
            base = os.path.splitext(mp3)[0]
            mp3_url = f"{base_url}/static/audio/{date_str}/{mp3}"
            json_url = f"{base_url}/static/audio/{date_str}/{base}.json"

            f.write(f"<li><strong>{base}</strong><br>\n")
            f.write(f'<audio controls src="{mp3_url}"></audio><br>\n')
            f.write(f'<a href="{mp3_url}">🔗 MP3</a> | <a href="{json_url}">🧾 JSON</a>\n')
            f.write("</li><br>\n")

        f.write("</ul></body></html>")
